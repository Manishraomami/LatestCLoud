@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view for Credit and Debit Note'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true
define root view entity ZR_CREDIT_DEBIT_NOTE
  as select from ZI_CREDIT_DEBIT_NOTE
{
  key    SupplierInvoice,
  key    FiscalYear,
         PurchaseOrder,
         DebitCredit,
         postingdate,
         vendor,
         SupplierName,
         streetname,
         cityname,
         Disctrict,
         PostalCode


}
