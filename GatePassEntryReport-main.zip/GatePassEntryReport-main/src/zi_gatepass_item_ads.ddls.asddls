@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Base View for ADS Gatepass Item'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_GATEPASS_ITEM_ADS
  as select from    zmm_gatepassitem    as _gpitem
    left outer join zmm_gateentryhdr    as _gphdr on _gphdr.gatepassnumber = _gpitem.gatepassnumber
  //                                                  and _gphdr.gatepasstype   = _gpitem.gatepasstype
    left outer join I_ProductPlantBasic as _pro   on  _pro.Product = _gpitem.materialnumber
                                                  and _pro.Plant   = _gphdr.plant
  //  association to parent ZI_GATEPASS_HDR_ADS as _hdr on  $projection.Gatepasstype   = _hdr.Gatepasstype
  //                                                    and $projection.Gatepassnumber = _hdr.Gatepassnumber

{

  key _gpitem.gatepasstype        as Gatepasstype,
  key _gpitem.gatepassnumber      as Gatepassnumber,
  key _gpitem.slno                as Slno,

      _gpitem.materialnumber      as Materialnumber,
      _gpitem.materialdescription as Materialdescription,
      @Semantics.quantity.unitOfMeasure : 'uom'
      _gpitem.quantity            as Quantity,
      _gpitem.uom                 as Uom,
      @Semantics.amount.currencyCode : 'currency'
      _gpitem.value               as Value,
      _gpitem.currency            as Currency,
      _gpitem.batchno             as Batchno,
      _gpitem.expectedreturndate  as Expectedreturndate,
      _gpitem.returndate          as Returndate,
      @Semantics.quantity.unitOfMeasure : 'uom'
      _gpitem.totalreceivedqty    as Totalreceivedqty,
      @Semantics.quantity.unitOfMeasure : 'uom'
      _gpitem.receivedqty         as Receivedqty,
      _gpitem.remarks             as ItemRemarks,
      @Semantics.user.createdBy: true
      _gpitem.createdby           as Createdby,
      @Semantics.systemDateTime.createdAt: true
      _gpitem.createdat           as Createdat,
      @Semantics.user.lastChangedBy: true
      _gpitem.lastchangedby       as Lastchangedby,
      @Semantics.systemDateTime.lastChangedAt: true
      _gpitem.lastchangedat       as Lastchangedat,
      _pro.ConsumptionTaxCtrlCode as Hsncode

      /* associations */
      //      _hdr

}
