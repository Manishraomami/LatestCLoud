@EndUserText.label: 'Custom entity for Vendor CN & DN form'
@ObjectModel.query.implementedBy: 'ABAP:ZCL_ADS_VENDOR_CN_DN'
define custom entity ZCustom_Vendor_ADS
{
  key Accounting_Document : abap.char( 10 );
  key Company_Code        : abap.char(4);
  key fiscal_Year         : gjahr;

      stream_data         : zattachment;

}
