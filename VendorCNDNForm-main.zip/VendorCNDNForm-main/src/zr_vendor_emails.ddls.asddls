@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view entity for Vendor Emails'
@Metadata.allowExtensions: true
define root view entity ZR_Vendor_Emails
  as select from ZI_Vendor_Emails

{
  key Supplier,
  key CcEmailId,
  ToEmailId,
      @Semantics.user.createdBy: true
      Createdby     as Createdby,
      @Semantics.systemDateTime.lastChangedAt: true
      Createdat     as Createdat,
      @Semantics.user.lastChangedBy: true
      Lastchangedby as Lastchangedby,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      Lastchangedat as Lastchangedat

}
