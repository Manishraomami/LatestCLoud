@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Journal entry details of header'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true
define root view entity ZI_Journal_Entry_Hdr
  as select from ZI_Journal_Entry_Header as Journal_Header
  association [1..*] to ZI_JOURNAL_ENTRY_ITM1 as _Item on  _Item.CompanyCode        = Journal_Header.CompanyCode
                                                       and _Item.FiscalYear         = Journal_Header.FiscalYear
                                                       and _Item.AccountingDocument = Journal_Header.AccountingDocument
{
  key Journal_Header.AccountingDocument,
  key Journal_Header.FiscalYear,
  key Journal_Header.CompanyCode,
      Journal_Header.DocumentDate,
      Journal_Header.Supplier,
      Journal_Header.SupplierName,
      Journal_Header.PostalCode,
      Journal_Header.DistrictName,
      Journal_Header.StreetName,
      Journal_Header.PhoneNumber1,
      Journal_Header.Region,
      Journal_Header.GSTNumber,
      Journal_Header.PostingDate,
      Journal_Header.PANnumber,
      Journal_Header.referencedocument,
      Journal_Header.AccountingDocumentType,
//      Journal_Header.longtext,
      //association
      _Item
}
