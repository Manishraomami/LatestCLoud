@AccessControl.authorizationCheck: #NOT_ALLOWED
@EndUserText.label: 'Consumption view Payment proposal Details'
@ObjectModel.modelingPattern: #ANALYTICAL_QUERY
@ObjectModel.supportedCapabilities: [#ANALYTICAL_QUERY]
@Metadata.allowExtensions: true
define root view entity ZC_Payment_Proposal_Hdr
  provider contract transactional_query
  as projection on ZR_Payment_Proposal_Hdr
{
  key PaymentDocument,
  key PayingCompanyCode,
  key FiscalYear,
  PostingDate ,//Added on 15.09.2025 for Email Triggering
  Supplier     //Added on 08.10.2025 for Email Triggering
}
