CLASS zcl_ads_gatepass DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.

    TYPES: BEGIN OF ty_filters,
             Gatepassnumber TYPE if_rap_query_filter=>ty_name_range_pairs-range,
             Gatepasstype   TYPE if_rap_query_filter=>ty_name_range_pairs-range,

           END OF ty_filters.

    METHODS:  read_filters IMPORTING filters_pair  TYPE if_rap_query_filter=>tt_name_range_pairs
                           RETURNING VALUE(result) TYPE ty_filters
                           RAISING   cx_root.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_ADS_GATEPASS IMPLEMENTATION.


  METHOD if_rap_query_provider~select.

    DATA: rt_table TYPE TABLE OF zcustom_ads.
    CONSTANTS: lv_fname TYPE string VALUE 'GatePassEntry',
               lv_tname TYPE string VALUE 'GatePassEntry'.

    TRY.
*        IF NOT io_request->is_data_requested(  ).
*          RETURN.
*        ENDIF.
**==>Gets the filters as ranges from the request.
        TRY.
            DATA(filters_pair) = io_request->get_filter( )->get_as_ranges( ).
          CATCH  cx_sy_ref_is_initial INTO DATA(lv_ref).
            lv_ref->get_longtext(  ).
          CATCH cx_rap_query_filter_no_range INTO DATA(error).
            error->get_longtext(  ).
            RETURN.
        ENDTRY.

**==>Reads the collection of filters from the filter pairs.
        TRY.
            DATA(filters) = read_filters( filters_pair ).
          CATCH cx_root INTO DATA(lv_root).
            lv_root->get_longtext(  ).
        ENDTRY.

        DATA(Ls_Gatepass) = filters-gatepassnumber[ sign = 'I' option = 'EQ' ]-low.
        DATA(Ls_Gatetype) = filters-gatepasstype[ sign = 'I' option = 'EQ' ]-low.
        DATA(lv_top)     = io_request->get_paging( )->get_page_size( ).
        DATA(lv_skip)    = io_request->get_paging( )->get_offset( ).
        DATA(lt_fields)  = io_request->get_requested_elements( ).
        DATA(lt_sort)    = io_request->get_sort_elements( ).


        "Initialize Template Store Client
        DATA(lo_store) = NEW zcl_fp_tmpl_store_client(
          iv_service_instance_name   = 'ZSC_ASD_STORE'       "name of the custom comm. scenario to connect to the template store
          iv_use_destination_service = abap_false  ).             "disable destination service, switch to custom communication arrangement

   DATA(lo_fdp_util) = cl_fp_fdp_services=>get_instance( 'ZUI_C_GATEPASS_ADS'  ).
        "Retrieve the key fields of the root node
        DATA(lt_keys)  = lo_fdp_util->get_keys( ).

        lt_keys[ name = 'GATEPASSNUMBER' ]-value = ls_gatepass. "lv_gatepass_number.
        lt_keys[ name = 'GATEPASSTYPE' ]-value = ls_gatetype."lv_gatepass_type.

        "get Adobe Form Template from Template store
        DATA(ls_template) = lo_store->get_template_by_name(
          iv_get_binary     = abap_true
          iv_form_name      = lv_fname                "<= form object in template store
          iv_template_name  = lv_tname                 "<= template (in form object) that should be used
        ).

        "Execute the data service and retrieve the data tree
        DATA(lv_xml) = lo_fdp_util->read_to_xml( lt_keys ).



        "render PDF and get the PDF in binary base64 format
        cl_fp_ads_util=>render_pdf(
          EXPORTING
            iv_xml_data     = lv_xml
            iv_xdp_layout   = ls_template-xdp_template
            iv_locale       = 'en_US'
          IMPORTING
            ev_pdf          = DATA(lv_pdf_stream)
            ev_pages        = DATA(lv_pages)
            ev_trace_string = DATA(lv_trace)
        ).

        "decode binary data into BASE64 format
        DATA(lv_pdf_stream_x) = cl_web_http_utility=>decode_x_base64( encoded = CONV string( lv_pdf_stream ) ).

        APPEND VALUE zcustom_ads( stream_data = lv_pdf_stream ) TO rt_table.
        io_response->set_data( rt_table ).
        io_response->set_total_number_of_records( lines( rt_table ) ).

      CATCH cx_fp_fdp_error cx_fp_ads_util zcx_fp_tmpl_store_error cx_rap_query_provider INTO DATA(lx_error).
        DATA(lv_msg) = lx_error->get_longtext(  ).
    ENDTRY.


  ENDMETHOD.


  METHOD read_filters.


    result-gatepassnumber = VALUE #( filters_pair[ name = 'GATEPASSNUMBER' ]-range OPTIONAL ).
    result-gatepasstype  = VALUE #( filters_pair[ name = 'GATEPASSTYPE' ]-range OPTIONAL ).

  ENDMETHOD.
ENDCLASS.
