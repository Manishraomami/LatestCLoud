@EndUserText.label: 'Custom entity For Gatepass Form'
@ObjectModel.query.implementedBy: 'ABAP:ZCL_ADS_GATEPASS'
define custom entity ZCUSTOM_ADS
//  with parameters
//
//    P_Gatepassnumber : zd_gatepassno,
//    P_Gatepasstype   : zd_gatepasstype
{

  key gatepassnumber : zd_gatepassno;
  key gatepasstype   : zd_gatepasstype;

      //  key mandt       : abap.clnt;
      //@Core.MediaType: 'application/pdf'
   stream_data    : zattachment;

}
