@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view entity for Payment proposal Header Details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define root view entity ZR_Payment_Proposal_Hdr
  as select distinct from I_PaymentProposalPayment as paymenthdr
 
{
 
  key paymenthdr.PaymentDocument,
  key paymenthdr.PayingCompanyCode,
  key paymenthdr._PaymentProposalItem.FiscalYear,
      paymenthdr.PostingDate, //Added on 15.09.2025 for email triggering
      paymenthdr.Supplier //Added on 08.10.2025 for email triggering
 
}
