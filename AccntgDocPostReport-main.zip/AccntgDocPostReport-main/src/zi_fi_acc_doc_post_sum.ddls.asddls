@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'FI GL Account Document Post Line Items Sum'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_FI_ACC_DOC_POST_SUM
  as select from ZI_FI_ACC_DOC_POST
{
  key AccountingDocument,

      CompanyCodeCurrency,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      sum(DebitAmount)  as TotalDebitAmount,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      sum(CreditAmount) as TotalCreditAmount
}
group by

  AccountingDocument,
  CompanyCodeCurrency
