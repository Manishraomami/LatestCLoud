@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Credit and Debtit Note item form'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_CRDR_NOTE_ITEM_FORM
  as select from    I_SuplrInvcItemPurOrdRefAPI01 as Invoiceitem
    left outer join I_ProductText                 as MaterialDiscrp on  Invoiceitem.PurchaseOrderItemMaterial = MaterialDiscrp.Product
                                                                    and MaterialDiscrp.Language               = 'E'
    left outer join I_PurchaseOrderItemAPI01      as PurItem        on  Invoiceitem.PurchaseOrder     = PurItem.PurchaseOrder
                                                                    and Invoiceitem.PurchaseOrderItem = PurItem.PurchaseOrderItem
{
  key Invoiceitem.SupplierInvoice,
  key Invoiceitem.SupplierInvoiceItem,
  key Invoiceitem.FiscalYear,
      //      concat( Invoiceitem.SupplierInvoice, Invoiceitem.FiscalYear ) as ComprKey,
      Invoiceitem.PurchaseOrder,
      Invoiceitem.PurchaseOrderItem,
      Invoiceitem.PurchaseOrderItemMaterial,
      MaterialDiscrp.ProductName,
      PurItem.BR_NCM,
      Invoiceitem.PurchaseOrderQuantityUnit,
      @Semantics.quantity.unitOfMeasure: 'PurchaseOrderQuantityUnit'
      Invoiceitem.QuantityInPurchaseOrderUnit,
      Invoiceitem.DocumentCurrency,
      @Semantics.amount.currencyCode: 'DocumentCurrency'
      Invoiceitem.SupplierInvoiceItemAmount
      //      _AccHeader


}
