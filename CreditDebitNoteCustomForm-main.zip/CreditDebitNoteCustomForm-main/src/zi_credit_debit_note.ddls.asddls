@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface for Credit Note and Debit Note'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_CREDIT_DEBIT_NOTE
  as select distinct from ZI_SUPPLIER_INVOICE_DETAILS as SupplierInvoice
  //  as select distinct from I_SuplrInvcItemPurOrdRefAPI01 as InvoiceItem
  //    inner join            I_SupplierInvoiceAPI01        as InvoiceHeader on  InvoiceItem.SupplierInvoice = InvoiceHeader.SupplierInvoice
  //                                                                         and InvoiceItem.FiscalYear      = InvoiceHeader.FiscalYear
    left outer join       I_Supplier                  as supplier on SupplierInvoice.InvoicingParty = supplier.Supplier

{
  key   SupplierInvoice.SupplierInvoice   as SupplierInvoice,
  key   SupplierInvoice.FiscalYear        as FiscalYear,
        SupplierInvoice.PurchaseOrder     as PurchaseOrder,
        SupplierInvoice.DebitCredit,
        SupplierInvoice.CreationDate      as postingdate,
        SupplierInvoice.InvoicingParty    as vendor,
        supplier.SupplierName             as SupplierName,
        supplier.StreetName               as streetname,
        supplier.CityName                 as cityname,
        supplier.PostalCode               as PostalCode,
        supplier.DistrictName             as Disctrict,
        supplier.BusinessPartnerPanNumber as PAN,
        supplier.TaxNumber3               as GSTIN
}

where
        SupplierInvoice.IsSubsequentDebitCredit is not initial
  or(
        SupplierInvoice.IsSubsequentDebitCredit is initial
    and SupplierInvoice.IsInvoice               is initial
  )
