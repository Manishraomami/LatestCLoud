@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view for credit and debit note form'
@Metadata.ignorePropagatedAnnotations: true
define root view entity ZR_CRDR_NOTE_FORM
  as select from    ZI_CRDR_NOTE_FORM       as Header
    left outer join Zi_CRDR_NOTE_TAXDETAILS as IGST on  Header.InvoiceYear                = IGST.OriginalReferenceDocument
                                                    and IGST.TransactionTypeDetermination = 'JII'
    left outer join Zi_CRDR_NOTE_TAXDETAILS as CGST on  Header.InvoiceYear                = CGST.OriginalReferenceDocument
                                                    and CGST.TransactionTypeDetermination = 'JIC'
    left outer join Zi_CRDR_NOTE_TAXDETAILS as SGST on  Header.InvoiceYear                = SGST.OriginalReferenceDocument
                                                    and SGST.TransactionTypeDetermination = 'JIS'
  association [1..*] to ZI_CRDR_NOTE_ITEM_FORM as _item on  $projection.SupplierInvoice = _item.SupplierInvoice
                                                        and $projection.FiscalYear      = _item.FiscalYear

{
  key Header.SupplierInvoice,
  key Header.FiscalYear,
      Header.PurchaseOrder,
      Header.DebitCredit,
      Header.postingdate,
      Header.ReferenceInvoiceNo,
      Header.ReferenceInvoiceDate,
      Header.InvoiceYear,
      Header.vendor,
      Header.SupplierName,
      Header.streetname,
      Header.cityname,
      Header.PostalCode,
      Header.Disctrict,
      abs(IGST.IGST) as IGST, // Ensure IGST is positive
      abs(CGST.CGST) as CGST, // Ensure CGST is positive
      abs(SGST.SGST) as SGST, // Ensure SGST is positive
      Header.PAN,
      Header.GSTin,
      Header.DocumentCurrency,
      Header.Plant,
      Header.PlantStreet,
      Header.PlantCity,
      Header.PlantDistrictName,
      Header.PlantPostalCode,
      Header.Telnumber,
      Header.Currency,
      @Semantics.amount.currencyCode: 'Currency'
      Header.TDSAmount,
      Header.PlantGSTIn,
      _item // Make association public
      //      _taxdetails
}
