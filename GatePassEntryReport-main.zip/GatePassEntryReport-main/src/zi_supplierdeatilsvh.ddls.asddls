@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Supplier Details Value Help'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
@ObjectModel.resultSet.sizeCategory: #XXS
@Search.searchable: true
define view entity ZI_SupplierDeatilsVH
  as select from    I_Supplier
    left outer join I_RegionText            as _text  on  I_Supplier.Region  = _text.Region
                                                      and I_Supplier.Country = _text.Country
                                                      and _text.Language     = $session.system_language
    left outer join I_AddressEmailAddress_2 as _email on  I_Supplier.AddressID   = _email.AddressID
                                                      and _email.AddressPersonID is initial
{
      @Search.defaultSearchElement: true
  key I_Supplier.Supplier,
      I_Supplier.BusinessPartnerName1,
      I_Supplier.TaxNumber3                             as GstNo,
      I_Supplier.PostalCode,
      concat(I_Supplier.StreetName,I_Supplier.CityName) as Address1,
      //      I_Supplier.AddressID
      cast( '' as abap.char( 50 ) )                     as Address,
      _text.RegionName                                  as state,
      _email.EmailAddress                               as emailaddress


}
