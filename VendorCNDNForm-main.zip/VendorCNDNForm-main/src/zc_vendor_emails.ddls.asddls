@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Consumption view for Vendor Email Details'
@Metadata.allowExtensions: true
define root view entity ZC_Vendor_Emails
  provider contract transactional_query
  as projection on ZR_Vendor_Emails
{
  key Supplier,
      //  key ToEmailId,
  key CcEmailId,
      ToEmailId,
      @Semantics.user.createdBy: true
      Createdby     as Createdby,
      @Semantics.systemDateTime.lastChangedAt: true
      Createdat     as Createdat,
      @Semantics.user.lastChangedBy: true
      Lastchangedby as Lastchangedby,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      Lastchangedat as Lastchangedat
}
