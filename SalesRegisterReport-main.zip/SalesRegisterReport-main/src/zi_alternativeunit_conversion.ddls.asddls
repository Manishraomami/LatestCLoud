@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface View for Alternative Unit Conversion'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_AlternativeUnit_Conversion
  as select from    I_BillingDocumentBasic     as billingheader

    inner join      I_BillingDocumentItemBasic as billingitem on billingitem.BillingDocument = billingheader.BillingDocument
    left outer join I_SalesDocumentItem        as salesitem   on  salesitem.SalesDocument                 = billingitem.SalesDocument
                                                              and salesitem.SalesDocumentItem             = billingitem.SalesDocumentItem
                                                              and billingitem.ReferenceSDDocumentCategory = 'J' //aubel
    left outer join I_ProductUnitsOfMeasure    as _KAR        on  _KAR.Product         = salesitem.Product
                                                              and _KAR.BaseUnit        = salesitem.OrderQuantityUnit
                                                              and _KAR.AlternativeUnit = 'KAR'
    left outer join I_ProductUnitsOfMeasure    as _JOG        on  _JOG.Product         = salesitem.Product
                                                              and _JOG.BaseUnit        = salesitem.OrderQuantityUnit
                                                              and _JOG.AlternativeUnit = 'JOG'
    left outer join I_ProductUnitsOfMeasure    as _NOS        on  _NOS.Product         = salesitem.Product
                                                              and _NOS.BaseUnit        = salesitem.OrderQuantityUnit
                                                              and _NOS.AlternativeUnit = 'NOS'

    left outer join I_ProductUnitsOfMeasure    as _PAK        on  _PAK.Product         = salesitem.Product
                                                              and _PAK.BaseUnit        = salesitem.OrderQuantityUnit
                                                              and _PAK.AlternativeUnit = 'PAK'

    left outer join I_ProductUnitsOfMeasure    as _GRO        on  _GRO.Product         = salesitem.Product
                                                              and _GRO.BaseUnit        = salesitem.OrderQuantityUnit
                                                              and _GRO.AlternativeUnit = 'GRO'
{
key billingheader.BillingDocument,
key billingitem.BillingDocumentItem,
 _KAR.AlternativeUnit,
 _KAR.QuantityNumerator,
 _NOS.AlternativeUnit as a1,
 _NOS.QuantityNumerator as q1,
 _PAK.AlternativeUnit as pak,
  case when _JOG.AlternativeUnit = 'JOG' then
  cast( _KAR.QuantityNumerator / _JOG.QuantityNumerator as abap.dec(5) ) 
  when _JOG.AlternativeUnit = 'NOS' then
  cast( _KAR.QuantityNumerator / _NOS.QuantityNumerator as abap.dec(5) )
  when _JOG.AlternativeUnit = 'PAK' then
  cast( _KAR.QuantityNumerator / _PAK.QuantityNumerator as abap.dec(5) )
   when _JOG.AlternativeUnit = 'GRO' then
  cast( _KAR.QuantityNumerator / _GRO.QuantityNumerator as abap.dec(5) ) else null end as JOGalternativunit,
  billingitem.Material
  
  // cds to be deleted
}

