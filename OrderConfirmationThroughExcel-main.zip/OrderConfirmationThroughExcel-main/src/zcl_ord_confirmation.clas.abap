CLASS zcl_ord_confirmation DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    CLASS-METHODS Order_confirmation
      IMPORTING mfg_order      TYPE aufnr
                orderid        TYPE char4
                yieldconf      TYPE p
                finalconf      TYPE char1
                postingdate    TYPE datum
      RETURNING VALUE(et_data) TYPE string.

  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_ORD_CONFIRMATION IMPLEMENTATION.


  METHOD order_confirmation.

    DATA lt_confirmation TYPE TABLE FOR CREATE i_productionordconfirmationtp.
    DATA lt_matldocitm TYPE TABLE FOR CREATE i_productionordconfirmationtp\_prodnordconfmatldocitm.
    DATA lt_plantstor  TYPE TABLE FOR CREATE zc_pp_plantstrloc.
    DATA lt_all_confirmations TYPE TABLE FOR CREATE i_productionordconfirmationtp.
    DATA lt_all_matldocitm TYPE TABLE FOR CREATE i_productionordconfirmationtp\_ProdnOrdConfMatlDocItm.
    FIELD-SYMBOLS <ls_matldocitm> LIKE LINE OF lt_matldocitm.
*        DATA lt_target TYPE SORTED TABLE OF LineType WITH UNIQUE KEY %target.
    DATA lt_target LIKE <ls_matldocitm>-%target.


    READ ENTITIES OF i_ProductionOrdConfirmationTP FORWARDING PRIVILEGED
     ENTITY ProductionOrderConfirmation
     EXECUTE GetConfProposal
     FROM VALUE #(
         ( %param-OrderID = mfg_order
           %param-OrderOperation = OrderId
           %param-ConfirmationYieldQuantity = YieldConf
*            %param-ConfirmationScrapQuantity = <fs_final>-CnfScrap
*           %param-OrderConfirmationRecordType = 'X'
           %param-Sequence = '000000'
*            %param-activityistobeproposed = abap_true
*           %param-quantityistobeproposed = abap_true
            ) )
     RESULT DATA(lt_confproposal)
     REPORTED DATA(lt_reported_conf).

**=> Looping the data based on the confirmation group details fetched from above lt_confproposals
    LOOP AT lt_confproposal ASSIGNING FIELD-SYMBOL(<ls_confproposal>).
      CLEAR lt_target.

      APPEND INITIAL LINE TO lt_confirmation ASSIGNING FIELD-SYMBOL(<ls_confirmation>).
*      DATA(lv_conf_cid) = |Conf{ sy-tabix }{ sy-index }|.
*      <ls_confirmation>-%cid = lv_conf_cid.
      <ls_confirmation>-%cid = 'Conf' && sy-tabix.
      <ls_confirmation>-%data = CORRESPONDING #( <ls_confproposal>-%param ).
      <ls_confirmation>-FinalConfirmationType = 'X'."finalconf.
      <ls_confirmation>-PostingDate  = postingdate.
*        lv_act_qty = <ls_confirmation>-ConfirmationYieldQuantity.
      <ls_confirmation>-ConfirmationYieldQuantity = YieldConf.
*        <ls_confirmation>-

*        IF <fs_final>-YieldCnf IS INITIAL OR <fs_final>-YieldCnf = 0.
*          APPEND VALUE #( %tky = <fs_final>-%tky ) TO failed_data-zi_ord_tbl.
*          APPEND VALUE #( %msg = new_message_with_text(
*            severity = if_abap_behv_message=>severity-warning
*            text = |Yield quantity missing or zero for Order: { <fs_final>-Mfgorder }| ) ) TO reported-zi_ord_tbl.
*          CONTINUE.
*        ENDIF.


      READ ENTITIES OF i_productionordconfirmationtp FORWARDING PRIVILEGED
      ENTITY productionorderconfirmation
      EXECUTE getgdsmvtproposal
      FROM VALUE #( ( confirmationgroup = <ls_confproposal>-confirmationgroup
*        %param-confirmationyieldquantity = <ls_confproposal>-%param-confirmationyieldquantity ) )
      %param-confirmationyieldquantity = <ls_confirmation>-ConfirmationYieldQuantity ) )

      RESULT DATA(lt_gdsmvtproposal)
      REPORTED DATA(lt_reported_gdsmvt).

      CHECK lt_gdsmvtproposal[] IS NOT INITIAL.

      CLEAR lt_target[].

      IF lt_gdsmvtproposal IS NOT INITIAL.
*              CLEAR lt_target.
*          CLEAR lt_target.
**=> Looping on the Goods movement available for the above order based on the confirmation group
        LOOP AT lt_gdsmvtproposal ASSIGNING FIELD-SYMBOL(<ls_gdsmvtproposal>) WHERE confirmationgroup = <ls_confproposal>-confirmationgroup.
          APPEND INITIAL LINE TO lt_target ASSIGNING FIELD-SYMBOL(<ls_target>).
          <ls_target> = CORRESPONDING #( <ls_gdsmvtproposal>-%param ).
          <ls_target>-%cid = 'Item' && sy-tabix.

*            READ ENTITIES OF zc_pp_plantstrloc
*            ENTITY zc_pp_plantstrloc
*            FROM VALUE #( ( Plant = <ls_target>-Plant
*                            StorageLocation = <ls_target>-StorageLocation ) )
*            RESULT DATA(ls_result).
*
*            IF ls_result IS INITIAL.
*              APPEND VALUE #( %tky = <fs_final>-%tky ) TO failed_data-zi_ord_tbl.
*              APPEND VALUE #( %msg = new_message_with_text( severity = if_abap_behv_message=>severity-error text = |No Plant/storage loc exists for { <fs_final>-Mfgorder } { <ls_target>-ReservationItem }| ) ) TO reported-zi_ord_tbl.
*              CONTINUE.
*            ENDIF.
        ENDLOOP.

**=> appending the Item level data to matldocitm
        APPEND VALUE #( %cid_ref = <ls_confirmation>-%cid
        %target = lt_target
        confirmationgroup = <ls_confproposal>-confirmationgroup ) TO lt_matldocitm.
      ELSE.
        CONTINUE. " Skip current loop iteration if no goods movement proposals found
      ENDIF.
    ENDLOOP.

**=> Checking whether header(lt_confirmation) and item level(lt_matldocitm) data is present
    IF lt_confirmation IS NOT INITIAL AND lt_matldocitm IS NOT INITIAL.

**=> Confirmation of order
      MODIFY ENTITIES OF i_productionordconfirmationtp FORWARDING PRIVILEGED
      ENTITY productionorderconfirmation
      CREATE FROM lt_confirmation
      CREATE BY \_prodnordconfmatldocitm FROM lt_matldocitm
      MAPPED DATA(lt_mapped)
      FAILED DATA(lt_failed)
      REPORTED DATA(lt_reported).

*      COMMIT ENTITIES.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
