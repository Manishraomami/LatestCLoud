@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'View for Duplicating the Item Level'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_GATEPASS_ITEM_ADS_DUP
  as select from ZI_GATEPASS_ITEM_ADS
{
  key Gatepasstype,
  key Gatepassnumber,
  key Slno,
      Materialnumber,
      Materialdescription,
      @Semantics.quantity.unitOfMeasure: 'Uom'
      Quantity,
      Uom,
      @Semantics.amount.currencyCode: 'Currency'
      Value,
      Currency,
      Batchno,
      Expectedreturndate,
      Returndate,
      @Semantics.quantity.unitOfMeasure: 'Uom'
      Totalreceivedqty,
      @Semantics.quantity.unitOfMeasure: 'Uom'
      Receivedqty,
      ItemRemarks,
      Createdby,
      Createdat,
      Lastchangedby,
      Lastchangedat,
      Hsncode
}
