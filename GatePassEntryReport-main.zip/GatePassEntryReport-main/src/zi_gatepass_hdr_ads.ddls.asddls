@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view for ADS Gatepass Report'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true

define root view entity ZI_GATEPASS_HDR_ADS
  as select from    zmm_gateentryhdr
  //    left outer join I_Customer as _cust on _cust.Customer = zmm_gateentryhdr.vendorcode
    left outer join I_Supplier                    as _supplier on zmm_gateentryhdr.vendorcode = _supplier.Supplier
    left outer join I_Plant                       as _plant    on zmm_gateentryhdr.plant = _plant.Plant
    left outer join I_Address_2                   as _adrc     on _plant.AddressID = _adrc.AddressID
    inner join      I_RegionText                  as _region   on  _adrc.Region     = _region.Region
                                                               and _adrc.Country    = _region.Country
                                                               and _region.Language = $session.system_language
    left outer join I_CountryText                 as _country  on  _adrc.Country     = _country.Country
                                                               and _country.Language = $session.system_language
    left outer join I_IN_PlantBusinessPlaceDetail as _gst      on _plant.Plant = _gst.Plant
    left outer join I_IN_BusinessPlaceTaxDetail   as _business on  _gst.CompanyCode   = _business.CompanyCode
                                                               and _gst.BusinessPlace = _business.BusinessPlace

  association [1..*] to ZI_GATEPASS_ITEM_ADS     as _item  on  _item.Gatepassnumber = $projection.Gatepassnumber
                                                           and _item.Gatepasstype   = $projection.Gatepasstype
  association [1..*] to ZI_GATEPASS_ITEM_ADS_DUP as _item1 on  _item1.Gatepassnumber = $projection.Gatepassnumber
                                                           and _item1.Gatepasstype   = $projection.Gatepasstype


{
  key zmm_gateentryhdr.gatepasstype        as Gatepasstype,
  key zmm_gateentryhdr.gatepassnumber      as Gatepassnumber,
      case when zmm_gateentryhdr.gatepasstype = 'NRGP'
      then 'DELIVERY CHALLAN cum NON RETURNABLE GATE PASS'
      else 'DELIVERY CHALLAN cum RETURNABLE GATE PASS'
      end                                  as TITLE,

      zmm_gateentryhdr.plant               as Plant,
      zmm_gateentryhdr.storagelocation     as Storagelocation,
      zmm_gateentryhdr.vendorcode          as Vendorcode,
      zmm_gateentryhdr.vendorname          as Vendorname,
      zmm_gateentryhdr.gstno               as Gstno,
      zmm_gateentryhdr.state               as State,
      zmm_gateentryhdr.pincode             as Pincode,
      zmm_gateentryhdr.address             as Address,
      zmm_gateentryhdr.vehicleno           as Vehicleno,
      zmm_gateentryhdr.departmentname      as Departmentname,
      zmm_gateentryhdr.requestername       as Requestername,
      zmm_gateentryhdr.transporterdetails  as Transporterdetails,
      zmm_gateentryhdr.remarks             as Remarks,
      zmm_gateentryhdr.lorry_num           as Lorrynum,
      zmm_gateentryhdr.modeoftransport     as Modeoftransport,
      @Semantics.user.createdBy: true
      zmm_gateentryhdr.createdby           as Createdby,
      @Semantics.systemDateTime.createdAt: true
      zmm_gateentryhdr.createdat           as Createdat,
      @Semantics.user.lastChangedBy: true
      zmm_gateentryhdr.lastchangedby       as Lastchangedby,
      @Semantics.systemDateTime.lastChangedAt: true
      zmm_gateentryhdr.lastchangedat       as Lastchangedat,
      zmm_gateentryhdr.printform           as printform,
      _supplier.OrganizationBPName1        as OrganizationBPName1,
      _supplier.StreetName                 as StreetName,
      _supplier.Country                    as Country,
      _supplier.CityName                   as Cityname,
      _supplier.PostalCode                 as Postalcode,
      _supplier.Region                     as Region,
      _supplier.DistrictName               as DistrictName,
      _supplier.TaxNumber3                 as TaxNumber3,
      _supplier.PhoneNumber1               as Phonenumber,
      _adrc.OrganizationName1              as OrganizationName1,
      _adrc.StreetPrefixName1              as StreetPrefixName1,
      _adrc.StreetPrefixName2              as StreetPrefixName2,
      _adrc.DistrictName                   as PlantDistrict,
      _adrc.Region                         as PlantRegion,
      _adrc.CityName                       as PlantCity,
      _adrc.VillageName                    as PlantVillage,
      _adrc.PostalCode                     as PlantPostal,
      _adrc.Country                        as PlantCountry,
      _region.RegionName                   as PlantRegionname,
      _country.CountryName                 as Plantcountryname,
      _business.IN_GSTIdentificationNumber as Plantgst,

      /* associations */
      _item, // Make association public
      _item1
}
