@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Journal Entry Header'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_Journal_Entry_Header
  as select distinct from I_JournalEntry             as Journal_Header
    left outer join       I_CompanyCode              as _Companycode              on _Companycode.CompanyCode = Journal_Header.CompanyCode
    left outer join       I_AccountingDocumentType   as _accoutingdocumenttype    on _accoutingdocumenttype.AccountingDocumentType = Journal_Header.AccountingDocumentType


{
  key Journal_Header.AccountingDocument,
  key Journal_Header.FiscalYear,
  key _Companycode.CompanyCode,
      Journal_Header.DocumentDate,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ].Supplier,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.SupplierName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.PostalCode,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.DistrictName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.StreetName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.PhoneNumber1,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.Region,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.TaxNumber3                     as GSTNumber,
      Journal_Header.PostingDate,
      substring(Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.TaxNumber3, 3, 10  ) as PANnumber,
      substring( Journal_Header.OriginalReferenceDocument , 1, 10 )                                                  as referencedocument,
      _accoutingdocumenttype.AccountingDocumentType

}
