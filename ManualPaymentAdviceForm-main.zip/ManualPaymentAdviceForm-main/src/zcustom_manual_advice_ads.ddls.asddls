@EndUserText.label: 'Custom entity for Vendor CN & DN form'
@ObjectModel.query.implementedBy: 'ABAP:ZCL_ADS_MANUAL_ADVICE'
define custom entity ZCustom_Manual_Advice_ADS
{

  key PaymentDocument   : abap.char(10);
  key Payingcompanycode : abap.char(4);
  key fiscalYear        : gjahr;

      stream_data       : zattachment;

}
