@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface for Tax details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity Zi_CRDR_NOTE_TAXDETAILS
  as select distinct from I_JournalEntry               as AccItem
    left outer join       I_OperationalAcctgDocTaxItem as Taxitem on  AccItem.AccountingDocument = Taxitem.AccountingDocument
                                                                  and AccItem.CompanyCode        = Taxitem.CompanyCode
                                                                  and AccItem.FiscalYear         = Taxitem.FiscalYear

{
  key AccItem.AccountingDocument,
  key AccItem.CompanyCode,
      AccItem.OriginalReferenceDocument,
      Taxitem.TransactionTypeDetermination,
      sum(case Taxitem.TransactionTypeDetermination
            when 'JIC' then cast(-Taxitem.TaxAmountInCoCodeCrcy as abap.dec( 13, 3 ))
            else 0 end ) as CGST,

      sum(case Taxitem.TransactionTypeDetermination
            when 'JIS' then cast(-Taxitem.TaxAmountInCoCodeCrcy as abap.dec( 13, 3 ))
            else 0 end ) as SGST,

      sum(case Taxitem.TransactionTypeDetermination
            when 'JII' then cast(-Taxitem.TaxAmountInCoCodeCrcy as abap.dec( 13, 3 ))
            else 0 end)  as IGST


}

group by
  AccItem.AccountingDocument,
  AccItem.CompanyCode,
  AccItem.OriginalReferenceDocument,
  Taxitem.TransactionTypeDetermination
