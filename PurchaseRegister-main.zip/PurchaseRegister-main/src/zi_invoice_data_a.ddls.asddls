@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Purchase Register Report'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_INVOICE_DATA_A
  as select from ZI_INVOICE_DATA
{
  key ProjectWbs,
  key Wbs,
  key FiscalYear,
  key PostingPeriod,
  key InvoiceNumber,
  key InvoiceNumberItem,
      PurchaseInvoiceDate,
      JeType,
      JournalEntryNumber,
      GRNNumber,
      GRNPostingDate,
      Supplier,
      SupplierName,
      SupplierAddress,
      Material,
      MaterialDescription,
      MaterialType,
      MaterialTypeDescr,
      GRNItem,
      @Semantics.quantity.unitOfMeasure: 'GRNUoM'
      GRNQuantity,
      GRNUoM,
      @Semantics.quantity.unitOfMeasure: 'GRNUoM'
      InvoiceQuantity,
      UnitPrice,
      Freight,
      Pack,
      UnitRate,
      InvoiceItemAmount as InvoiceItemAmount,
      InvoiceCurrency,
      //  IGST,
      case when creditindicator = 'H'
      then IGST * -1
      else IGST
      end               as IGST, //Added on 16 June 25
      //  SGST,
      case when creditindicator = 'H'
      then SGST * -1
      else SGST
      end               as SGST, //Added on 16 June 25
      //  CGST,
      case when creditindicator = 'H'
      then CGST * -1
      else CGST
      end               as CGST, //Added on 16 June 25
      //  cast(coalesce(IGST, 0) + coalesce(SGST, 0) + coalesce(CGST, 0) as abap.dec(17,2)) as TotalGST,
      case when creditindicator = 'H'
      then cast( coalesce(IGST, 0) + coalesce(SGST, 0) + coalesce(CGST, 0) as abap.dec(17,2) ) * -1
      else cast( coalesce(IGST, 0) + coalesce(SGST, 0) + coalesce(CGST, 0) as abap.dec(17,2) )
      end               as TotalGST, //Added on 16 June 25
      //  TDS               as TDS,
      case when creditindicator = 'H'
      then TDS * -1
      else TDS
      end               as TDS, //Added on 16 June 25
      //    coalesce(IGST, 0) + coalesce(SGST, 0) + coalesce(CGST, 0) + coalesce(TDS, 0)  as TotalTax,
      //    coalesce(IGST, 0) + coalesce(SGST, 0) + coalesce(CGST, 0) + coalesce(InvoiceItemAmount, 0) as InvoiceTotal
      SupplierGSTNo,
      SupplierPANNo,
      SupplierRegion,
      SupplierDistrict,
      GRGLAccount,
      GRGLAccountName,
      TaxRate,
      TaxCode,
      CompanyCode,
      Plant,
      PurchaseOrderType,
      PurchaseOrder,
      Incoterms,
      PurchaseOrderDate,
      PurchaseRequisition,
      RequisitionDate,
      PaymentTerms,
      UserId,
      HSNSac,
      BankAccount,
      //      Advance,
      case
        when creditindicator = 'H' and Advance is not initial
        then concat( Advance , '-' )
        else Advance
      end               as Advance, //Added on 16 June 25
      //      case
      //         when creditindicator = 'H'
      //         then cast(  Advance as abap.dec( 13, 2 ) ) * -1
      //         else cast( Advance as abap.dec( 13, 2 ) )
      //       end              as Advance,
      //      Retention,
      case
        when creditindicator = 'H' and Retention is not initial
        then concat(Retention , '-')
        else Retention
      end               as Retention, //Added on 16 June 25
      //      LDV,
      case
        when creditindicator = 'H' and LDV is not initial
        then concat(LDV ,'-')
        else LDV
      end               as LDV, //Added on 16 June 25
      //      WithHeld,
      case
        when creditindicator = 'H' and WithHeld is not initial
        then concat(WithHeld,'-')
        else WithHeld
      end               as WithHeld,
      //      NetPayableValue,
      case
        when creditindicator = 'H' and NetPayableValue is not initial
        then concat(NetPayableValue,'-')
        else NetPayableValue
      end               as NetPayableValue,
      TransporterName,
      TransporterGSTNo,
      EwayBillNo,
      EwayBillDate,
      GRLRNo,
      GRLRDate,
      BankGurantee,
      VenInsrCert,
      NSEIAction,
      SalesInvoice,
      SalesInvoiceDate,
      DCNo,
      DelvChallanDate,
      BillSchNo,
      creditindicator
}
