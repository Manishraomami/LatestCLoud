@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Payment proposal Details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_Payment_Proposal_Hdr
  as select from    I_PaymentProposalPayment  as _paymenthdr
    left outer join I_OperationalAcctgDocItem as _item         on _item.AccountingDocument = _paymenthdr.PaymentDocument
    left outer join I_JournalEntry            as _journalEntry on _journalEntry.AccountingDocument = _paymenthdr.PaymentDocument
    left outer join I_Housebank               as _housebank    on _housebank.HouseBank = _paymenthdr.HouseBank
    left outer join I_Bank_2                  as _bankdetails  on  _bankdetails.BankInternalID = _housebank.BankInternalID
                                                               and _bankdetails.BankCountry    = _housebank.BankCountry
{
  key _paymenthdr.PaymentDocument,
  key _paymenthdr.PayingCompanyCode,
  key _paymenthdr._PaymentProposalItem.FiscalYear,
      _paymenthdr.PaymentRunDate,
      _paymenthdr.HouseBank,
      _paymenthdr.Supplier,
      _paymenthdr.OrganizationBPName1,
      _paymenthdr.PostalCode,
      _paymenthdr.Region,
      _paymenthdr.CityName,
      _paymenthdr.StreetAddressName,
      _item.DocumentItemText,
      _journalEntry.DocumentReferenceID,
      _bankdetails.BankName,
      _bankdetails.ShortCityName               as bank_cityname,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      abs( _item.AmountInCompanyCodeCurrency ) as AmountInCompanyCodeCurrency,
      _item.CompanyCodeCurrency,
      _item.AssignmentReference        
}

where
  _item.TransactionTypeDetermination = 'ZAH'
