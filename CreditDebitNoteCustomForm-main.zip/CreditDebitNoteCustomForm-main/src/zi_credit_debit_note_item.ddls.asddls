@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Credit Note and Debit Note Item'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_CREDIT_DEBIT_NOTE_ITEM
  as select from    I_SuplrInvcItemPurOrdRefAPI01 as Invoiceitem
    left outer join I_ProductText                 as MaterialDiscrp on  Invoiceitem.PurchaseOrderItemMaterial = MaterialDiscrp.Product
                                                                    and MaterialDiscrp.Language               = 'E'
    left outer join I_PurchaseOrderItemAPI01      as PurItem        on  Invoiceitem.PurchaseOrder     = PurItem.PurchaseOrder
                                                                    and Invoiceitem.PurchaseOrderItem = PurItem.PurchaseOrderItem
  association [1..*] to Zi_CRDR_NOTE_TAXDETAILS as _taxdetails on $projection.ComprKey = _taxdetails.OriginalReferenceDocument
{
  key Invoiceitem.SupplierInvoice,
  key Invoiceitem.SupplierInvoiceItem,
  key Invoiceitem.FiscalYear,
      concat( Invoiceitem.SupplierInvoice, Invoiceitem.FiscalYear ) as ComprKey,
      Invoiceitem.PurchaseOrder,
      Invoiceitem.PurchaseOrderItem,
      Invoiceitem.PurchaseOrderItemMaterial,
      MaterialDiscrp.ProductName,
      PurItem.BR_NCM,
      Invoiceitem.PurchaseOrderQuantityUnit,
      @Semantics.quantity.unitOfMeasure: 'PurchaseOrderQuantityUnit'
      Invoiceitem.QuantityInPurchaseOrderUnit,
      Invoiceitem.DocumentCurrency,
      @Semantics.amount.currencyCode: 'DocumentCurrency'
      Invoiceitem.SupplierInvoiceItemAmount,
      _taxdetails


}
