@EndUserText.label: 'Custom entity for Credit and Debit Note'
@ObjectModel.query.implementedBy: 'ABAP:ZCL_ADS_CREDIT_DEBIT_NOTE'
define custom entity ZCRDR_CUSTOM_ENTITY
  // with parameters parameter_name : parameter_type
{
  key SupplierInvoice : re_belnr;
  key FiscalYear      : gjahr;
      stream_data     : zattachment;

}
