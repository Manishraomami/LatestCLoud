@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Root view entity for Payment proposal Details'
@Metadata.allowExtensions: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define root view entity ZR_Payment_Proposal_Details
  as select distinct from ZI_Payment_Proposal_Hdr as _Header
  association [1..*] to ZI_Payment_Proposal_Itm as _Item on _Item.PaymentDocument = _Header.PaymentDocument

{
  key _Header.PaymentDocument,
  key _Header.PayingCompanyCode,
  key _Header.FiscalYear,
      _Header.PaymentRunDate,
      _Header.HouseBank,
      _Header.Supplier,
      _Header.OrganizationBPName1,
      _Header.PostalCode,
      _Header.Region,
      _Header.CityName,
      _Header.StreetAddressName,
      _Header.DocumentItemText,
      _Header.DocumentReferenceID,
      _Header.BankName,
      _Header.bank_cityname,
      _Header.AmountInCompanyCodeCurrency,
      _Header.CompanyCodeCurrency,
      _Header.AssignmentReference,
      
//Associations
      _Item
}
