@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for item Purpose'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_JOURNAL_ENTRY_ITM1
  as select from ZI_Journal_Entry_Itm
{
  key AccountingDocument,
  key FiscalYear,
  key CompanyCode,
  key AccountingDocumentItem,
      DocumentDate,
      PostingDate,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      AmountInCompanyCodeCurrency,
      CompanyCodeCurrency,
      TransactionTypeDetermination,
      IN_HSNOrSACCode,
      GLAccountLongName,
      IN_GSTIdentificationNumber,
      RegionName,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      AmountInfunctionalCurrency,
      GLAccount,
      TaxRate,
      TaxCode,
      longtext,
      FinancialAccountType
}
