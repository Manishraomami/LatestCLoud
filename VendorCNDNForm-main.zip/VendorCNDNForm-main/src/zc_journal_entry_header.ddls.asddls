@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Consumption view for JournalEntry Header'
@Metadata.allowExtensions: true
define root view entity ZC_Journal_Entry_Header
  provider contract transactional_query
  as projection on ZR_Journal_Entry_Header
{
  key AccountingDocument,
  key FiscalYear,
  key CompanyCode,
      DocumentDate,
      Supplier,
      SupplierName,
      PostalCode,
      DistrictName,
      StreetName,
      PhoneNumber1,
      Region,
      GSTNumber,
      PostingDate,
      PANnumber,
      referencedocument,
      AccountingDocumentType,
      AccountingDocumentCreationDate,
      CreationTime
}
