@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Base View For Supplier invoice details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_SUPPLIER_INVOICE_DETAILS
  as select from I_SuplrInvcItemPurOrdRefAPI01 as InvoiceItem
    inner join   I_SupplierInvoiceAPI01        as InvoiceHeader on  InvoiceItem.SupplierInvoice = InvoiceHeader.SupplierInvoice
                                                                and InvoiceItem.FiscalYear      = InvoiceHeader.FiscalYear
{

  key   InvoiceItem.SupplierInvoice as SupplierInvoice,
  key   InvoiceItem.FiscalYear      as FiscalYear,
        InvoiceItem.PurchaseOrder   as PurchaseOrder,
        case InvoiceItem.DebitCreditCode
        when 'S' then 'Debit Note'
        when 'H' then 'Credit Note'
        end                         as DebitCredit,
        InvoiceHeader.IsInvoice,
        InvoiceItem.IsSubsequentDebitCredit,
        InvoiceItem.DebitCreditCode,
        InvoiceHeader.InvoicingParty,
        InvoiceHeader.CreationDate
}
