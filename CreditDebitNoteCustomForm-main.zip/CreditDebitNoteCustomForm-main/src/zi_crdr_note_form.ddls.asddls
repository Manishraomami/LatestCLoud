@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Credit and Debtit Note form'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_CRDR_NOTE_FORM
  as select distinct from I_SuplrInvcItemPurOrdRefAPI01 as InvoiceItem
    inner join            I_SupplierInvoiceAPI01        as InvoiceHeader on  InvoiceItem.SupplierInvoice = InvoiceHeader.SupplierInvoice
                                                                         and InvoiceItem.FiscalYear      = InvoiceHeader.FiscalYear
    left outer join       I_Supplier                    as supplier      on InvoiceHeader.InvoicingParty = supplier.Supplier
    left outer join       I_Plant                       as _plant        on InvoiceItem.Plant = _plant.Plant
    left outer join       I_Address_2                   as _Address      on _plant.AddressID = _Address.AddressID
    left outer join       I_AddressPhoneNumber_2        as _PhoneNum     on _plant.AddressID = _PhoneNum.AddressID
    left outer join       I_OperationalAcctgDocItem     as Accounting    on  InvoiceHeader.SupplierInvoiceWthnFiscalYear = Accounting.OriginalReferenceDocument
                                                                         and Accounting.WithholdingTaxCode               = '1C'
                                                                         and Accounting.TransactionTypeDetermination     = 'WIT'
    left outer join       I_IN_PlantBusinessPlaceDetail as _gst          on InvoiceItem.Plant = _gst.Plant
    left outer join       I_IN_BusinessPlaceTaxDetail   as _business     on  _gst.CompanyCode   = _business.CompanyCode
                                                                         and _gst.BusinessPlace = _business.BusinessPlace


{
  key   InvoiceItem.SupplierInvoice                 as SupplierInvoice,
  key   InvoiceItem.FiscalYear                      as FiscalYear,
        InvoiceItem.PurchaseOrder                   as PurchaseOrder,
        case InvoiceItem.DebitCreditCode
        when 'S' then 'Debit Note'
        when 'H' then 'Credit Note'
        end                                         as DebitCredit,
        InvoiceHeader.CreationDate                  as postingdate,
        InvoiceHeader.SupplierInvoiceIDByInvcgParty as ReferenceInvoiceNo,
        InvoiceHeader.DocumentDate                  as ReferenceInvoiceDate,
        InvoiceHeader.SupplierInvoiceWthnFiscalYear as InvoiceYear,
        InvoiceHeader.InvoicingParty                as vendor,
        supplier.SupplierName                       as SupplierName,
        supplier.StreetName                         as streetname,
        supplier.CityName                           as cityname,
        supplier.PostalCode                         as PostalCode,
        supplier.DistrictName                       as Disctrict,
        supplier.BusinessPartnerPanNumber           as PAN,
        supplier.TaxNumber3                         as GSTin,
        InvoiceHeader.DocumentCurrency,
        _plant.Plant                                as Plant,
        _Address.StreetPrefixName1                  as PlantStreet,
        _Address.CityName                           as PlantCity,
        _Address.PostalCode                         as PlantPostalCode,
        _Address.DistrictName                       as PlantDistrictName,
        _PhoneNum.PhoneAreaCodeSubscriberNumber     as Telnumber,
        Accounting.CompanyCodeCurrency              as Currency,
        @Semantics.amount.currencyCode: 'Currency'
        Accounting.AmountInCompanyCodeCurrency      as TDSAmount,
        _business.IN_GSTIdentificationNumber        as PlantGSTIn


}

//where
//  InvoiceItem.IsSubsequentDebitCredit <> ''
where
        InvoiceItem.IsSubsequentDebitCredit is not initial
  or(
        InvoiceItem.IsSubsequentDebitCredit is initial
    and InvoiceHeader.IsInvoice             is initial
  )
