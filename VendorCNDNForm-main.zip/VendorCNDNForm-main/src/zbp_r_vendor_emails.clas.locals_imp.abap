CLASS lhc_ZR_Vendor_Emails DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR ZR_Vendor_Emails RESULT result.
    METHODS supplier_toemail FOR DETERMINE ON MODIFY
      IMPORTING keys FOR zr_vendor_emails~supplier_toemail.

*    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
*      IMPORTING REQUEST requested_authorizations FOR ZR_Vendor_Emails RESULT result.

ENDCLASS.

CLASS lhc_ZR_Vendor_Emails IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

*  METHOD get_global_authorizations.
*  ENDMETHOD.

  METHOD Supplier_toemail.


    READ ENTITIES OF ZR_Vendor_Emails IN LOCAL MODE
        ENTITY ZR_Vendor_Emails
        ALL FIELDS WITH CORRESPONDING #( keys )
        RESULT DATA(lt_emails).

    IF lt_emails IS INITIAL.
      RETURN.
    ENDIF.

    SELECT SINGLE FROM @lt_emails AS _email
       LEFT OUTER JOIN I_Supplier WITH PRIVILEGED ACCESS AS _supp ON _email~Supplier = _supp~Supplier
       LEFT OUTER JOIN I_AddressEmailAddress_2 WITH PRIVILEGED ACCESS AS _EmailAddress ON  _EmailAddress~AddressID       = _supp~AddressID
                                                                                         AND _EmailAddress~AddressPersonID IS INITIAL
       FIELDS _EmailAddress~EmailAddress
       INTO @DATA(lv_supp_email).
*

    LOOP AT lt_emails ASSIGNING FIELD-SYMBOL(<fs_email>).

      <fs_email>-ToEmailId = lv_supp_email.

    ENDLOOP.
    DATA lt_email_upd1 TYPE TABLE FOR UPDATE ZR_Vendor_Emails.
    lt_email_upd1 = CORRESPONDING #( lt_emails ).

    MODIFY ENTITIES OF ZR_Vendor_Emails IN LOCAL MODE
      ENTITY ZR_Vendor_Emails
      UPDATE FIELDS ( ToEmailId )
      WITH CORRESPONDING #( lt_email_upd1 )
      REPORTED DATA(modified).


    reported-zr_vendor_emails = CORRESPONDING #( modified-zr_vendor_emails ).


  ENDMETHOD.

ENDCLASS.
