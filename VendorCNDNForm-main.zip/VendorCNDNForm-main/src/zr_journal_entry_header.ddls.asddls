@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Journal Entry Header'
@Metadata.allowExtensions: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define root view entity ZR_Journal_Entry_Header
  as select distinct from I_JournalEntry as Journal_Header
{
  key Journal_Header.AccountingDocument,
  key Journal_Header.FiscalYear,
  key Journal_Header._CompanyCode.CompanyCode,
      Journal_Header.DocumentDate,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ].Supplier,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.SupplierName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.PostalCode,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.DistrictName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.StreetName,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.PhoneNumber1,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.Region,
      Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.TaxNumber3                    as GSTNumber,
      Journal_Header.PostingDate,
      substring(Journal_Header._OperationalAcctgDocItem[ FinancialAccountType = 'K' ]._Supplier.TaxNumber3, 3, 9  ) as PANnumber,
      Journal_Header.OriginalReferenceDocument                                                                      as referencedocument,
      Journal_Header._AccountingDocumentType.AccountingDocumentType,
      Journal_Header.CreationTime, //Added on 16.09.2025 for Email Triggering
      Journal_Header.AccountingDocumentCreationDate //Added on 16.09.2025 for Email Triggering
}
where
  Journal_Header._AccountingDocumentType.AccountingDocumentType = 'KR'
  or //Added on 15.09.2025
  Journal_Header._AccountingDocumentType.AccountingDocumentType = 'KG'
