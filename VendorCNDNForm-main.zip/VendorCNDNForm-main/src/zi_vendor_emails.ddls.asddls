@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Vendor Emails'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_Vendor_Emails
  as select from zfi_email_tab
{
  key supplier      as Supplier,
  key cc_email_id   as CcEmailId,
      to_email_id   as ToEmailId,
      @Semantics.user.createdBy: true
      createdby     as Createdby,
      @Semantics.systemDateTime.lastChangedAt: true
      createdat     as Createdat,
      @Semantics.user.lastChangedBy: true
      lastchangedby as Lastchangedby,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      lastchangedat as Lastchangedat
}
