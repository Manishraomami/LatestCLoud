@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Journal Entry Item Details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_Journal_Entry_Itm
  as select distinct from I_OperationalAcctgDocItem    as _OperationalAcctgDocItem

    left outer join       I_IN_BusinessPlaceTaxDetail  as _businessplace            on  _businessplace.CompanyCode   = _OperationalAcctgDocItem.CompanyCode
                                                                                    and _businessplace.BusinessPlace = _OperationalAcctgDocItem.BusinessPlace
    left outer join       I_GLAccountInChartOfAccounts as _glaccountchartofaccounts on  _glaccountchartofaccounts.ChartOfAccounts = _OperationalAcctgDocItem.ChartOfAccounts
                                                                                    and _glaccountchartofaccounts.GLAccount       = _OperationalAcctgDocItem.GLAccount
    left outer join       I_Supplier                   as _supplier                 on _supplier.Supplier = _OperationalAcctgDocItem.Supplier
    left outer join       I_Region                     as _region                   on  _region.Region  = _supplier.Region
                                                                                    and _region.Country = _supplier.Country
    left outer join       I_OperationalAcctgDocTaxItem as _TaxItem                  on  _TaxItem.AccountingDocument           = _OperationalAcctgDocItem.AccountingDocument
                                                                                    and _TaxItem.FiscalYear                   = _OperationalAcctgDocItem.FiscalYear
                                                                                    and _TaxItem.CompanyCode                  = _OperationalAcctgDocItem.CompanyCode
                                                                                    and _TaxItem.TransactionTypeDetermination = _OperationalAcctgDocItem.TransactionTypeDetermination
    left outer join       I_GLAccountLineItemRawData   as _GLAccountLineItemRawData on  _GLAccountLineItemRawData.AccountingDocument     = _OperationalAcctgDocItem.AccountingDocument
                                                                                    and _GLAccountLineItemRawData.FiscalYear             = _OperationalAcctgDocItem.FiscalYear
                                                                                    and _GLAccountLineItemRawData.CompanyCode            = _OperationalAcctgDocItem.CompanyCode
                                                                                    and _GLAccountLineItemRawData.AccountingDocumentItem = _OperationalAcctgDocItem.AccountingDocumentItem


{
  key     _OperationalAcctgDocItem.AccountingDocument,
  key     _OperationalAcctgDocItem.FiscalYear,
  key     _OperationalAcctgDocItem.CompanyCode,
  key     _OperationalAcctgDocItem.AccountingDocumentItem,
          _OperationalAcctgDocItem.DocumentDate,
          _OperationalAcctgDocItem.PostingDate,
          @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
          _OperationalAcctgDocItem.AmountInCompanyCodeCurrency,
          _OperationalAcctgDocItem.CompanyCodeCurrency,
          _OperationalAcctgDocItem.TransactionTypeDetermination,
          _OperationalAcctgDocItem.IN_HSNOrSACCode,
          _glaccountchartofaccounts._Text[ Language = $session.system_language ].GLAccountLongName,
          _businessplace.IN_GSTIdentificationNumber,
          _region._RegionText[ Language = $session.system_language ].RegionName                                                                                                   as RegionName,
          @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
          _OperationalAcctgDocItem.AmountInFunctionalCurrency                                                                                                                     as AmountInfunctionalCurrency,
          _OperationalAcctgDocItem.GLAccount,
          cast( round( ( cast ( _TaxItem.TaxAmountInTransCrcy as abap.dec(23, 3) ) / cast( _TaxItem.TaxBaseAmountInTransCrcy as abap.dec(23, 3) ) * 100 ),3 ) as abap.dec(23,1) ) as TaxRate,
          _OperationalAcctgDocItem.TaxCode,
          _GLAccountLineItemRawData.YY1_Item_Text_JEI                                                                                                                             as longtext,
          _OperationalAcctgDocItem.FinancialAccountType
}

//where
//_OperationalAcctgDocItem.FinancialAccountType <> 'K'
