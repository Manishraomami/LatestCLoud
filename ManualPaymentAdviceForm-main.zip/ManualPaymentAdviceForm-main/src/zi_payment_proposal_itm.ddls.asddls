@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Payment proposal Item Details'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZI_Payment_Proposal_Itm
  as select from I_PaymentProposalItem as _PaymentItem
{
  key   _PaymentItem.PaymentDocument,
  key   _PaymentItem.CompanyCode,
  key   _PaymentItem.FiscalYear,
        _PaymentItem.AccountingDocument,
        _PaymentItem._OperationalAcctgDocItem.DocumentItemText,
        @Semantics.amount.currencyCode: 'PaymentCurrency'
        abs( _PaymentItem.NetAmountInCoCodeCurrency ) as NetAmountInCoCodeCurrency,
        _PaymentItem.PaymentCurrency,
        @Semantics.amount.currencyCode: 'PaymentCurrency'
        abs( _PaymentItem.WhldgTaxAmtInCoCodeCrcy )   as WhldgTaxAmtInCoCodeCrcy,
        _PaymentItem._OperationalAcctgDocItem.PostingDate

}
