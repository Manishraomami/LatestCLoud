@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Interface view for Sales Register'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZI_SALES_REGISTER
  as select from    I_BillingDocumentItemBasic     as billingitem
    left outer join I_BillingDocItemPrcgElmntBasic as CGST          on  CGST.BillingDocument     = billingitem.BillingDocument
                                                                    and CGST.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and CGST.ConditionType       = 'JOCG'

    left outer join I_BillingDocItemPrcgElmntBasic as SGST          on  SGST.BillingDocument     = billingitem.BillingDocument
                                                                    and SGST.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and SGST.ConditionType       = 'JOSG'

    left outer join I_BillingDocItemPrcgElmntBasic as IGST          on  IGST.BillingDocument     = billingitem.BillingDocument
                                                                    and IGST.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and IGST.ConditionType       = 'JOIG'

    left outer join I_BillingDocItemPrcgElmntBasic as discount1     on  discount1.BillingDocument     = billingitem.BillingDocument
                                                                    and discount1.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and discount1.ConditionType       = 'ZDSC'

    left outer join I_BillingDocItemPrcgElmntBasic as discount2     on  discount2.BillingDocument     = billingitem.BillingDocument
                                                                    and discount2.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and discount2.ConditionType       = 'ZDOC'

    left outer join I_BillingDocItemPrcgElmntBasic as roundup       on  roundup.BillingDocument     = billingitem.BillingDocument
                                                                    and roundup.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and roundup.ConditionType       = 'DRD1' //'DIFF' "changed on 08042025


    left outer join I_BillingDocItemPrcgElmntBasic as MRP           on  MRP.BillingDocument     = billingitem.BillingDocument
                                                                    and MRP.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and MRP.ConditionType       = 'ZPRM'

    left outer join I_BillingDocItemPrcgElmntBasic as Unit_Price    on  Unit_Price.BillingDocument     = billingitem.BillingDocument
                                                                    and Unit_Price.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and Unit_Price.ConditionType       = 'ZBAS'

    left outer join I_BillingDocItemPrcgElmntBasic as Cash_Discount on  Cash_Discount.BillingDocument     = billingitem.BillingDocument
                                                                    and Cash_Discount.BillingDocumentItem = billingitem.BillingDocumentItem
                                                                    and Cash_Discount.ConditionType       = 'ZDSA'
{
  key billingitem.BillingDocument                                                                                                      as billingdocument,
  key billingitem.BillingDocumentItem                                                                                                  as billingdocumentitem,

      floor( IGST.ConditionRateValue )                                                                                                 as igst,
      floor( CGST.ConditionRateValue )                                                                                                 as cgst,
      floor( SGST.ConditionRateValue )                                                                                                 as sgst,
      cast( IGST.ConditionAmount  as abap.dec(15,2) )                                                                                  as igstvalue,
      cast( CGST.ConditionAmount as abap.dec(15,2) )                                                                                   as cgstvalue,
      cast( SGST.ConditionAmount as abap.dec(15,2) )                                                                                   as sgstvalue,
      IGST.TransactionCurrency                                                                                                         as transactioncurrency,
      CGST.TransactionCurrency                                                                                                         as transaction_currency,
      SGST.TransactionCurrency                                                                                                         as trans_currency,
      cast( roundup.ConditionAmount as abap.dec(15,2) )                                                                                as roundup,
      coalesce(cast( discount1.ConditionAmount as abap.dec(13,2) ),0) + coalesce(cast(discount2.ConditionAmount as abap.dec(13,2) ),0) as discount_amount,
      discount1.TransactionCurrency                                                                                                    as Transactioncur,
      cast( MRP.ConditionAmount as abap.dec(15,2) )                                                                                    as mrp_value,
      round( Unit_Price.ConditionRateValue ,2 )                                                                                        as unit_price,
      cast( Cash_Discount.ConditionAmount as abap.dec(15,2) )                                                                          as cashdiscount


}
